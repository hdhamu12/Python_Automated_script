# Friend-Recommender-System
• Designed and implemented a Recommender System for the Delicious Dataset to produce Novel and Serendipitous Recommendations.
• Around 68k Bookmarks and 53k tags.
• More time efficient than previous approaches and produced highly serendipitous results with a marked increase in user satisfaction and precision metrics. 
